<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>home page</name>
   <tag></tag>
   <elementGuidId>1160db3d-abfc-4b38-9048-200c0abb4a47</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>svg.a8c37x1j.ms05siws.l3qrxjdp.b7h9ocf4.g28tu32o > path</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>path</value>
      <webElementGuid>6da0a09f-62c1-42dc-8e79-897ac11f60d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>d</name>
      <type>Main</type>
      <value>M25.825 12.29C25.824 12.289 25.823 12.288 25.821 12.286L15.027 2.937C14.752 2.675 14.392 2.527 13.989 2.521 13.608 2.527 13.248 2.675 13.001 2.912L2.175 12.29C1.756 12.658 1.629 13.245 1.868 13.759 2.079 14.215 2.567 14.479 3.069 14.479L5 14.479 5 23.729C5 24.695 5.784 25.479 6.75 25.479L11 25.479C11.552 25.479 12 25.031 12 24.479L12 18.309C12 18.126 12.148 17.979 12.33 17.979L15.67 17.979C15.852 17.979 16 18.126 16 18.309L16 24.479C16 25.031 16.448 25.479 17 25.479L21.25 25.479C22.217 25.479 23 24.695 23 23.729L23 14.479 24.931 14.479C25.433 14.479 25.921 14.215 26.132 13.759 26.371 13.245 26.244 12.658 25.825 12.29</value>
      <webElementGuid>e7e96713-75d4-4b32-96f7-2a6561997d05</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mount_0_0_ZK&quot;)/div[1]/div[1]/div[@class=&quot;rq0escxv l9j0dhe7 du4w35lb&quot;]/div[2]/div[@class=&quot;kr520xx4 j9ispegn poy2od1o n7fi1qx3 tkr6xdv7&quot;]/div[@class=&quot;rq0escxv l9j0dhe7 du4w35lb cddn0xzi j83agx80 cbu4d94t byvelhso&quot;]/div[@class=&quot;rq0escxv l9j0dhe7 du4w35lb j83agx80 cbu4d94t bkfpd7mw&quot;]/div[@class=&quot;taijpn5t byvelhso j83agx80&quot;]/ul[@class=&quot;thodolrn ojvp67qx taijpn5t buofh1pr j83agx80 aovydwv3 bqdfd6uv&quot;]/li[@class=&quot;buofh1pr to382e16 o5zgeu5y dawyy4b1 jrc8bbd0 hw7htvoc&quot;]/span[@class=&quot;tojvnm2t a6sixzi8 abs2jz4q a8s20v7p t1p8iaqh k5wvi7nf q3lfd5jv pk4s997a bipmatt0 cebpdrjk qowsmv63 owwhemhu dp1hu0rb dhp61c6y iyyx5f41&quot;]/div[@class=&quot;bp9cbjyn j83agx80 byvelhso l9j0dhe7&quot;]/a[@class=&quot;oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso i1ao9s8h esuyzwwr f1sip0of n00je7tq arfg74bv qs9ysxi8 k77z8yql abiwlrkh p8dawk7l lzcic4wl bp9cbjyn j83agx80 cbu4d94t datstx6m taijpn5t l9j0dhe7 k4urcfbm&quot;]/span[@class=&quot;l9j0dhe7&quot;]/svg[@class=&quot;a8c37x1j ms05siws l3qrxjdp b7h9ocf4 g28tu32o&quot;]/path[1]</value>
      <webElementGuid>c70c9d1b-4c81-440a-9fff-9cad4c1f71ac</webElementGuid>
   </webElementProperties>
</WebElementEntity>
