<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_sign up</name>
   <tag></tag>
   <elementGuidId>69f0d1d4-3058-42b2-9d69-aafcf5cbcf2c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.mbs._52lq.fsl.fwb.fcb</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//html[@id='facebook']/body/div[4]/div[2]/div/div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>00bc0a9e-ac2a-4728-b8b5-bb5c2e218e89</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mbs _52lq fsl fwb fcb</value>
      <webElementGuid>1d2a4bc0-db0a-434e-9ed0-0fec81aaf492</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign Up</value>
      <webElementGuid>6021a931-babe-422b-b2e5-3883c7e22589</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;facebook&quot;)/body[@class=&quot;fbIndex UIPage_LoggedOut _-kb _605a b_c3pyn-ahh chrome webkit win x1 Locale_en_GB cores-gte4 _19_u&quot;]/div[@class=&quot;_n8 _3qx _8idq _8esf _8f3m _8fgk uiLayer _3qw&quot;]/div[@class=&quot;_n9&quot;]/div[@class=&quot;_n3&quot;]/div[@class=&quot;_8ien&quot;]/div[@class=&quot;pvl _52lp _59d-&quot;]/div[@class=&quot;mbs _52lq fsl fwb fcb&quot;]</value>
      <webElementGuid>237be766-f14c-4b59-ba0b-ce139b998834</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//html[@id='facebook']/body/div[4]/div[2]/div/div/div/div</value>
      <webElementGuid>836015c0-a414-4bac-afb6-69a31d70fc67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Meta © 2022'])[1]/following::div[11]</value>
      <webElementGuid>17049a06-d248-4754-a7a4-b41dd8a448d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Activity log'])[1]/following::div[13]</value>
      <webElementGuid>e4699bc5-77a9-4609-96b7-6e84ad94c45f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('It', &quot;'&quot;, 's quick and easy.')])[1]/preceding::div[1]</value>
      <webElementGuid>9db456c0-73fc-464e-a418-a3f6b34de253</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='An error occurred. Please try again.'])[1]/preceding::div[2]</value>
      <webElementGuid>99c7edec-afe4-4d2c-9e45-af6df6e7b995</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]/div/div/div/div</value>
      <webElementGuid>6b4a172e-2a0f-46f2-a02a-44ee4a272308</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Sign Up' or . = 'Sign Up')]</value>
      <webElementGuid>c75c47e8-eb30-4a90-94de-4e21cf25fc07</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
